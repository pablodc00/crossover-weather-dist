package com.crossover.trial.weather;

/**
 * An internal exception marker
 */
public class WeatherException extends Exception { //CR: Doesn't define any new behaviour, unnecessary
}
